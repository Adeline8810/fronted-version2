import { Routes } from '@angular/router';

// Páginas
import { LandingComponent } from './pages/landing/landing.component';
import { LoginComponent } from './pages/login/login.component';
import { RegisterComponent } from './pages/register/register.component';
import { SlamComponent } from './pages/slam/slam.component';
import { AdminComponent } from './pages/admin/admin.component';

// Guard simple (directo, sin servicio)
function adminGuard() {
  const usuario = JSON.parse(localStorage.getItem('usuario') || 'null');
  return usuario?.usuario === 'ruthadeline';
}

export const routes: Routes = [
  // Landing page (pantalla rosada)
  { path: '', component: LandingComponent },

  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },

  // SLAM general (cualquier usuario logueado podrá entrar)
  { path: 'slam', component: SlamComponent },

  // Admin (solo Ruth entra)
  {
    path: 'admin',
    component: AdminComponent,
    canMatch: [adminGuard]
  },

  // Cualquier ruta inválida redirige a landing
  { path: '**', redirectTo: '' }
];
