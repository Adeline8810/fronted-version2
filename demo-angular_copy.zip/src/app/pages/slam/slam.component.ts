import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MenuBarComponent } from '.././../components/menu-bar/menu-bar.component';
import { PreguntaService } from '../../../services/pregunta.service';

@Component({
  selector: 'app-slam',
  standalone: true,
  imports: [CommonModule, FormsModule, MenuBarComponent],
  templateUrl: './slam.component.html',
  styleUrls: ['./slam.component.css']
})
export class SlamComponent implements OnInit {

  preguntaActual = 0;
  respuestaActual = '';

  preguntas: any[] = [];   // ⬅⬅⬅ IMPORTANTE: inicializar vacío PARA EVITAR ERRORES

  constructor(private preguntaService: PreguntaService) {}

  ngOnInit(): void {

    // Cargar las preguntas desde la BD
    this.preguntaService.obtenerPreguntas().subscribe({
      next: (data) => {
        this.preguntas = data;
      },
      error: (err) => console.log('Error cargando preguntas', err)
    });
  }


  anterior() {
  if (this.preguntaActual > 0) {
    this.preguntaActual--;
    this.respuestaActual = '';
  }
}

saltar() {
  if (this.preguntaActual < this.preguntas.length - 1) {
    this.preguntaActual++;
    this.respuestaActual = '';
  }
}

siguiente() {
  if (this.preguntaActual < this.preguntas.length - 1) {
    this.preguntaActual++;
    this.respuestaActual = '';
  }
}

}
