import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MenuBarComponent } from '../../components/menu-bar/menu-bar.component';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule, MenuBarComponent],
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {

  usuario = JSON.parse(localStorage.getItem('usuario') || 'null');
  esAdmin = this.usuario?.username === 'ruthadeline';

}
