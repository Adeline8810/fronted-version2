import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  email: string = '';
  password: string = '';

  constructor(private router: Router) {}

  login() {
    if (!this.email || !this.password) {
      alert('Por favor ingresa tu email y contraseña');
      return;
    }

    // ADMIN: ruthadeline
    if (this.email === 'ruthadeline@gmail.com' && this.password === '123456') {
      localStorage.setItem('role', 'admin');
      this.router.navigate(['/landing']);
      return;
    }

    // USUARIO NORMAL
    localStorage.setItem('role', 'user');
    this.router.navigate(['/landing']);
  }

  goRegister() {
    this.router.navigate(['/register']);
  }
}
