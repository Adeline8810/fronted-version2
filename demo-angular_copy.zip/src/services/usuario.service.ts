import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Usuario } from '../models/usuario';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

  private apiUrl = 'http://localhost:8080/api/usuarios';

  constructor(private http: HttpClient) {}

  register(usuario: Usuario): Observable<Usuario> {
    return this.http.post<Usuario>(`${this.apiUrl}/register`, usuario);
  }

  login(username: string, password: string): Observable<Usuario> {
    return this.http.post<Usuario>(`${this.apiUrl}/login`, { username, password });
  }

  listar(): Observable<Usuario[]> {
    return this.http.get<Usuario[]>(`${this.apiUrl}`);
  }

  getOne(id: number): Observable<Usuario> {
    return this.http.get<Usuario>(`${this.apiUrl}/${id}`);
  }

  update(id: number, usuario: Usuario): Observable<Usuario> {
    return this.http.put<Usuario>(`${this.apiUrl}/${id}`, usuario);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

eliminar(id: number) {
  return this.http.delete(`${this.apiUrl}/${id}`);
}

obtenerUsuarios() {
  return this.http.get<any[]>(`${this.apiUrl}`);
}



  // Alias con nombre en español que tus componentes esperan (agregarUsuario)
agregarUsuario(usuario: Partial<Usuario>) {
  return this.http.post(this.apiUrl, usuario);
}


  // Obtener uno por id
  obtenerUsuarioPorId(id: number): Observable<Usuario> {
    return this.http.get<Usuario>(`${this.apiUrl}/${id}`);
  }

  // Actualizar usuario (PUT)
  actualizarUsuario(id: number, usuario: Partial<Usuario>) {
  return this.http.put(`${this.apiUrl}/${id}`, usuario);
}

  // Eliminar usuario (DELETE)
  eliminarUsuario(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }


}
