export interface Respuesta {
  id?: number;
  usuarioId?: number;
  preguntaId?: number;
  texto?: string | null;
  foto?: string | null;
}
