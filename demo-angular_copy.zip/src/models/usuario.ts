export interface Usuario {
  id: number;        // <-- OBLIGATORIO porque tus componentes siempre lo usan
  nombre: string;
  username: string;
  email: string;
  password?: string; // opcional porque en el listado no viene
}
