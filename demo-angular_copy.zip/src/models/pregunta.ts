export interface Pregunta {
  id: number;
  texto: string;
}
